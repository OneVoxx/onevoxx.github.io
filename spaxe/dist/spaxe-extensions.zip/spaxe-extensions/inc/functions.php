<?php
/**
 * Main functions and Template hooks used in Spaxe.
 *
 * @author OneVoxx
 * @version 1.0.0
 */

if ( get_theme_mod( 'active_custon_login_page' ) != "" ) {
	/**
	 * Functions
	 *
	 * @see spaxe_redirect_to_page()
	 * @see spaxe_login_failed()
	 * @see spaxe_authenticate_username_and_password()
	 */

	add_action( 'init',									'spaxe_redirect_to_page'							 );
	add_action( 'wp_login_failed',						'spaxe_login_failed'								 );
	add_filter( 'authenticate',							'spaxe_authenticate_username_and_password',		1, 3 );
}

/**
 * Shortcodes
 *
 * @see spaxe_registration_shortcode()
 * @see spaxe_post_slider_shortcode()
 * @see spaxe_members_slider_shortcode()
 * @see spaxe_members_shortcode()
 * @see spaxe_home_products()
 */

add_shortcode( 'spaxe_registration_form',			'spaxe_registration_shortcode'						);
add_shortcode( 'spaxe_post_slider',					'spaxe_post_slider_shortcode'						);
add_shortcode( 'spaxe_members_slider',				'spaxe_members_slider_shortcode'					);
add_shortcode( 'spaxe_members',						'spaxe_members_shortcode'							);
add_shortcode( 'spaxe_home_products',				'spaxe_home_products'								);

/**
 * Registration form.
 */
function spaxe_registration_form( $username, $password, $email ) {

	global $username, $password, $email;

	echo '
	<form class="register-form p-5 bg-white" action="' . esc_attr( get_permalink() ) . '" method="post">
		<h2 class="register-title text-center mb-1" itemprop="headline">' . get_theme_mod( 'register_title' ) . '</h2>

		<p class="subtitle text-center">' . get_theme_mod( 'register_subtitle' ) . '</p>

		<div class="col-md-12 px-0">
			<span class="icon"><i class="cix icon-user"></i></span>

			<label for="username">' . esc_html__( 'Username', 'spaxe-extensions' ) . '</label>

			<input type="text" name="username" placeholder="' . esc_html__( 'Username', 'spaxe-extensions' ) . '" value="' . ( isset( $_POST['username'] ) ? $username : null ) . '" aria-required="true" required="required">
		</div>

		<div class="col-md-12 px-0">
			<span class="icon"><i class="sli icon-lock"></i></span>

			<label for="password">' . esc_html__( 'Password', 'spaxe-extensions' ) . '</label>

			<input type="password" name="password" placeholder="' . esc_html__( 'Password', 'spaxe-extensions' ) . '" value="' . ( isset( $_POST['password'] ) ? $password : null ) . '" aria-required="true" required="required">

			<span toggle="#password" class="fa fa-eye-slash show-password"></span>
		</div>

		<div class="col-md-12 px-0">
			<span class="icon"><i class="cix icon-at"></i></span>

			<label for="email">' . esc_html__( 'Email', 'spaxe-extensions' ) . '</label>

			<input type="text" name="email" placeholder="' . esc_html__( 'Email', 'spaxe-extensions' ) . '" value="' . ( isset( $_POST['email']) ? $email : null ) . '" aria-required="true" required="required">
		</div>

		<div class="col-md-12 px-0">
			<div class="checkbox text-left mb-4">
				<label for="privacy-policy">
					<input type="checkbox" name="privacy-policy" id="privacy-policy" value="yes" aria-required="true" required="required">

					<span class="field-visibility-text">' . do_shortcode( stripslashes( get_theme_mod( 'register_form_privacy_policy_control' ) ) ) . '</span>
				</label>
			</div>
		</div>

		<div class="button-register">
			<input type="submit" name="submit" class="w-100" value="' . esc_html__( 'Complete Sign Up', 'spaxe-extensions' ) . '">
		</div>

		<span class="link-to-login text-center">' . esc_html__( 'Have an account?', 'spaxe-extensions' ) . ' <a href="#link-to-login" class="font-weight-bold">' . esc_html__( 'Log In', 'spaxe-extensions' ) . '</a></span>
	</form>';
}

/**
 * Check if there is an error.
 */
function spaxe_registration_form_error( $username, $password, $email )  {

	global $spaxe_error_validation;

	$spaxe_error_validation = new WP_Error;

	if ( 4 > strlen( $username ) ) {

		$spaxe_error_validation->add( 'username_length', __( 'Username must be at least 4 characters.', 'spaxe-extensions' ) );

		foreach ( $spaxe_error_validation->get_error_messages( 'username_length' ) as $error ) {

			echo '<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-times mt-1 mr-2 left text-danger"></i><p class="text-danger text-left mb-0">' . $error . '</p></div>';
		}
	}

	if ( username_exists( $username ) ) {

		$spaxe_error_validation->add( 'user_name', __( 'Sorry, that username already exists!', 'spaxe-extensions' ) );

		foreach ( $spaxe_error_validation->get_error_messages( 'user_name' ) as $error ) {

			echo '<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-times mt-1 mr-2 left text-danger"></i><p class="text-danger text-left mb-0">' . $error . '</p></div>';
		}
	}

	if ( ! validate_username( $username ) ) {

		$spaxe_error_validation->add( 'username_invalid', __( 'Usernames can contain only letters, numbers, ., -, and @', 'spaxe-extensions' ) );

		foreach ( $spaxe_error_validation->get_error_messages( 'username_invalid' ) as $error ) {

			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times mt-1 mr-2 left text-danger"></i><p class="text-danger text-left mb-0">' . $error . '</p></div>';
		}
	}

	if ( 5 > strlen( $password ) ) {

		$spaxe_error_validation->add( 'password', __( 'Password must be at least 5 characters.', 'spaxe-extensions' ) );

		foreach ( $spaxe_error_validation->get_error_messages( 'password' ) as $error ) {

			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times mt-1 mr-2 left text-danger"></i><p class="text-danger text-left mb-0">' . $error . '</p></div>';
		}
	}

	if ( ! is_email( $email ) ) {

		$spaxe_error_validation->add( 'email_invalid', __( 'Sorry, that email address is not allowed!', 'spaxe-extensions' ) );

		foreach ( $spaxe_error_validation->get_error_messages( 'email_invalid' ) as $error ) {

			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times mt-1 mr-2 left text-danger"></i><p class="text-danger text-left mb-0">' . $error . '</p></div>';
		}
	}

	if ( email_exists( $email ) ) {

		$spaxe_error_validation->add( 'email', __( 'Sorry, that email address is already used!', 'spaxe-extensions' ) );

		foreach ( $spaxe_error_validation->get_error_messages( 'email' ) as $error ) {

			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times mt-1 mr-2 left text-danger"></i><p class="text-danger text-left mb-0">' . $error . '</p></div>';
		}
	}
}

/**
 * Registration complete when all is okay.
 */
function spaxe_registration_form_completed() {

	global $spaxe_error_validation, $username, $password, $email;

	if ( 1 > count( $spaxe_error_validation->get_error_messages() ) ) {

		$userdata = array(
			'user_login'	=> $username,
			'user_email'	=> $email,
			'user_pass'		=> $password
		);

		$user = wp_insert_user( $userdata );

		echo '<div class="registration-completed"><div class="alert alert-success" role="alert"><i class="fas fa-check-circle h5 mt-2 mr-2 left text-success"></i><p class="text-success text-left mb-0">' . __( 'Congratulations! you have successfully created your account.', 'spaxe-extensions' ) . '</p></div>';

		spaxe_login_form();

		echo '</div>';
	}
}

/**
 * Spaxe registration.
 */
function spaxe_registration_form_shortcode() {

	global $username, $password, $email;

	if ( is_user_logged_in() ) {

		$current_user = wp_get_current_user();

		echo '<div class="user-logged-message bg-white text-center"><div class="bg-message"></div><div class="message-content p-5"><h3 class="mb-1">' . esc_html( $current_user->display_name ) . '</h3><p>' . esc_html__( 'You are now logged in.', 'spaxe-extensions' ) . '</p><button class="go-back"><a href="' . get_home_url() . '">' . esc_html__( 'Go Back to Home', 'spaxe-extensions' ) . ' </a></button></div></div>';

	} else {

		if ( isset($_POST['submit'] ) ) {

			spaxe_registration_form_error(
				$_POST['username'],
				$_POST['password'],
				$_POST['email']
			);

			$username	= sanitize_user( $_POST['username'] );
			$password	= esc_attr( $_POST['password'] );
			$email		= sanitize_email( $_POST['email'] );

			spaxe_registration_form_completed(
				$username,
				$password,
				$email
			);
		}

		spaxe_registration_form(
			$username,
			$password,
			$email
		);
	}
}

/**
 * Spaxe Log In form.
 */
function spaxe_login_form() {

	$redirect_to = home_url();

	if ( is_user_logged_in() ) {

		$current_user = wp_get_current_user();

		echo '<div class="user-logged-message bg-white text-center"><div class="bg-message"></div><div class="message-content p-5"><h3 class="mb-1">' . esc_html( $current_user->display_name ) . '</h3><p>' . esc_html__( 'You are now logged in.', 'spaxe-extensions' ) . '</p><button class="go-back"><a href="' . get_home_url() . '">' . esc_html__( 'Go Back to Home', 'spaxe-extensions' ) . ' </a></button></div></div>';

	} else {

	$login = ( isset( $_GET['login'] ) ) ? $_GET['login'] : 0;

	if ( $login === 'empty' ) {

		echo '<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle h5 mr-2 left text-danger"></i><p class="text-danger mb-0">' . esc_html__( 'You are now logged out.', 'spaxe-extensions' ) . '</p></div>';

	} else if ( $login === 'failed' ) {

		echo '<div class="alert alert-danger mt-3" role="alert"><i class="fas fa-exclamation-triangle h5 mr-2 left text-danger"></i><p class="text-danger mb-0">' . esc_html__( 'The username or password is incorrect.', 'spaxe-extensions' ) . '</p></div>';
	}

	?>

	<form id="login-form" class="login-form p-5 bg-white" name="login-form" action="<?php echo esc_url( wp_login_url( add_query_arg( array(), $wp->request ) ) ); ?>" method="post">

		<div class="login-logo">
			<a href="<?php echo esc_attr( $redirect_to ); ?>">
				<div class="small-logo mx-auto mb-2"></div>
			</a>
		</div>

		<h4 class="login-title text-center mb-1" itemprop="headline"><?php echo get_theme_mod( 'login_title' ); ?></h4>

		<p class="login-subtitle text-center mb-4"><?php echo get_theme_mod( 'register_subtitle' ); ?></p>

		<div class="col-md-12 px-0">
			<span class="icon"><i class="cix icon-user"></i></span>

			<label for="username"><?php esc_html_e( 'Username', 'spaxe-extensions' ); ?></label>

			<input type="text" name="log" id="user_login" placeholder="<?php esc_html_e( 'Username', 'spaxe-extensions' ); ?>" value="">
		</div>

		<div class="col-md-12 px-0">
			<span class="icon"><i class="sli icon-lock"></i></span>

			<label for="password"><?php esc_html_e( 'Password', 'spaxe-extensions' ); ?></label>

			<input type="password" name="pwd" id="user_pass" placeholder="<?php esc_html_e( 'Password', 'spaxe-extensions' ); ?>" value="">
		</div>

		<div class="col-md-12 px-0">
			<div class="checkbox left">
				<label for="rememberme">
					<input type="checkbox" name="rememberme" id="rememberme" value="forever">

					<span class="field-visibility-text"><?php esc_html_e( 'Remember Me', 'spaxe-extensions' ); ?></span>
				</label>
			</div>
		</div>

		<div class="lost-password right">
			<a href="<?php echo wp_lostpassword_url( home_url() ); ?>"><?php esc_html_e( 'Lost Password?', 'spaxe-extensions' ); ?></a>
		</div>

		<input type="submit" id="wp-submit" name="wp-submit" class="w-100 mt-4 mb-3" value="<?php esc_html_e( 'Log In', 'spaxe-extensions' ); ?>">

		<input type="hidden" value="<?php echo esc_attr( $redirect_to ); ?>" name="redirect_to">

		<input type="hidden" value="1" name="cookie">

		<span class="link-to-register text-center"><?php esc_html_e( 'Don’t have an account?', 'spaxe-extensions' ); ?> <a href="#link-to-register" class="font-weight-bold"><?php get_theme_mod( 'register_title' ); ?></a></span>
	</form>

	<?php }
}

if ( get_theme_mod( 'active_custon_login_page' ) != "" ) {
	/**
	 * Redirect WordPress login to custom login page.
	 */
	function spaxe_redirect_to_page() {

		$login_url = home_url( '/login/' );

		$page_viewed = basename( home_url( $wp->request ) );

		if ( $page_viewed == 'wp-login.php' && $wp->request == 'GET' ) {

			wp_redirect( $login_url );

			exit;
		}
	}

	/**
	 * Login failed.
	 */
	function spaxe_login_failed() {

		$login_page = home_url( '/login/' );

		wp_redirect( $login_page . '?login=failed' );

		exit;
	}

	/**
	 * Authenticate username and password for custom login page.
	 */
	function spaxe_authenticate_username_and_password( $user, $username, $password ) {

		$login_page = home_url( '/login/' );

		if ( $username == '' || $password == '' ) {

			wp_redirect( $login_page . '?login=empty' );

			exit;
		}
	}
}

<?php
/**
 * Spaxe shortcodes.
 *
 * @author OneVoxx
 * @version 1.0.0
 */

if ( ! function_exists( 'spaxe_registration_shortcode' ) ) {
	/**
	 * Spaxe Registration
	 *
	 * @version	1.0.0
	 * @since	1.0.0
	 * @author	OneVoxx
	 */
	function spaxe_registration_shortcode() {

		ob_start();

		echo '<div class="register-content front">';

		spaxe_registration_form_shortcode();

		echo '</div>';

		echo '<div class="login-content">';

		spaxe_login_form();

		echo '</div>';
		
		return ob_get_clean();
	}
}

if ( ! function_exists( 'spaxe_post_slider_shortcode' ) ) {
	/**
	 * Spaxe Post Slider
	 *
	 * @version	1.0.0
	 * @since	1.0.0
	 * @author	OneVoxx
	 */
	function spaxe_post_slider_shortcode() {

		ob_start();

			$args = array(
				'post_parent'		=> get_the_ID(),
				'post_type'			=> 'attachment',
				'orderby'			=> 'menu_order',
				'order'				=> 'ASC',
				'numberposts'		=> 10,
				'post_mime_type'	=> 'image',
			);

			if ( $images = get_children( $args ) ) :

				echo '<ul id="post-slider" class="owl-carousel owl-theme list-unstyled ml-0">';

					foreach( $images as $image ) :

						echo '<li>' . wp_get_attachment_image( $image->ID, 'spaxe-post-slider' ) . '</li>';

					endforeach;

				echo '</ul>';

			endif;

		return ob_get_clean();
	}
}

if ( function_exists( 'is_buddypress' ) ) {
	/**
	 * Spaxe Members Slider
	 *
	 * @version	1.0.0
	 * @since	1.0.0
	 * @author	OneVoxx
	 */
	if ( ! function_exists( 'members_slider' ) ) {
		/**
		 * add Members Slider.
		 *
		 * @return	ob_get_clean
		 */
		function members_slider( $query, $style, $size ) {

			if ( ! $query )
				return;

			ob_start(); ?>

			<?php if ( bp_has_members( $query ) ) : ?>

				<ul id="members-list" class="members-slider m-0">

					<div class="members-carousel owl-carousel owl-theme">

						<?php while ( bp_members() ) : bp_the_member(); ?>

							<li <?php bp_member_class( array( 'list-unstyled text-center' ) ); ?> data-bp-item-id="<?php bp_member_user_id(); ?>" data-bp-item-component="members">

								<div class="list-wrap">
									<div class="item-avatar pt-5">
										<a class="d-inline-block avatar position-relative pt-4" href="<?php bp_member_permalink(); ?>">
											<?php bp_member_avatar( array(
												'type'		=> 'full',
												'width'		=> $size,
												'height'	=> $size,
												'class'		=> $style,
												'alt'		=> bp_get_member_name(),
											) ); ?>
										</a>
									</div>

									<h2 class="list-title member-name mt-5 mb-1">
										<a class="font-weight-bold" href="<?php bp_member_permalink(); ?>"><?php bp_member_name(); ?></a>
									</h2>

									<span class="member-subtitle w-100">
										<?php
											/***
											* If you want to show specific profile fields here you can,
											* but it'll add an extra query for each member in the loop
											* (only one regardless of the number of fields you show):
											*/
											echo bp_member_profile_data( 'field=Location' );
										?>
									</span>
								</div>
							</li>
						<?php endwhile; ?>
					</div>
				</ul>
			<?php endif; ?>
		<?php

		return ob_get_clean();

		}
	}

	function spaxe_members_slider_shortcode( $atts ) {
		/**
		 * Add Members Shortcode.
		 *
		 * Options
		 * Type: Active, Alphabetical, Newest, Online, Popular, Random.
		 * Number: Number of items.
		 * Size: Size of avatar on pixels.
		 * Style: rounded, rounded-0, rounded-circle, rounded-bottom, rounded-left, rounded-right, rounded-top.
		 *
		 * @return	members_slider
		 */
		extract( shortcode_atts( array(
			'view'			=> 'slider',
			'filter'		=> 'active',
			'number'		=> 10,
			'user_type'		=> null,
			'size'			=> '80',
			'style'			=> ''
		), $atts ) );

		$query = "type=$filter&max=$number";

		return members_slider( $query, $style, $size );
	}

	/**
	 * Spaxe Members
	 *
	 * @version	1.0.0
	 * @since	1.0.0
	 * @author	OneVoxx
	 */
	if ( ! function_exists( 'spaxe_members' ) ) {
		/**
		 * Spaxe Members.
		 *
		 * @return	ob_get_clean
		 */
		function spaxe_members( $query, $style, $size ) {

			if ( ! $query )
				return;

			ob_start(); ?>

			<?php if ( bp_has_members( $query ) ) : ?>

				<ul id="members-list" class="members-list m-0">

				<?php while ( bp_members() ) : bp_the_member(); ?>

					<li <?php bp_member_class( array( 'member list-unstyled text-center left col-3' ) ); ?> data-bp-item-id="<?php bp_member_user_id(); ?>" data-bp-item-component="members">

						<div class="list-wrap">
							<div class="left">
								<?php echo spaxe_get_membership(); ?>
							</div>

							<?php if ( bp_is_active( 'is_messages' ) ) : ?>
								<div class="show-nav">
									<i class="cix icon-ellipsis-h btn-show-nav"></i>

									<div class="hide-nav">
										<div class="send-message-icon">
											<a data-tooltip="Send Message" data-position="tooltip-left" class="send-message text-center tooltip-left" href="<?php echo spaxe_get_send_private_message_url(); ?>"><i class="fas fa-envelope"></i></a>
										</div>

										<div class="send-mention-icon">
											<a data-tooltip="Send Mention" data-position="tooltip-left" class="send-mention text-center tooltip-left" href="<?php echo spaxe_get_send_public_message_url(); ?>"><i class="far fa-at"></i></a>
										</div>
									</div>
								</div>
							<?php endif; ?>

							<div class="item-avatar pt-5">
								<a class="d-inline-block position-relative pt-4" href="<?php bp_member_permalink(); ?>">
									<?php bp_member_avatar( array(
										'type'		=> 'full',
										'width'		=> $size,
										'height'	=> $size,
										'class'		=> array( 'avatar', $style ),
										'alt'		=> bp_get_member_name(),
									) ); ?>
								</a>
							</div>

							<h2 class="list-title member-name mt-3 mb-0">
								<a class="font-weight-bold" href="<?php bp_member_permalink(); ?>"><?php bp_member_name(); ?></a>
							</h2>

							<?php if ( bp_is_active( 'follow' ) ) : ?>

								<span class="follow-count w-100 d-inline-block"><?php echo spaxe_total_member_follow_counts( bp_get_member_user_id() ); ?> <?php esc_html_e( 'Followers', 'spaxe-extensions' ); ?></span>

							<?php endif; ?>

							<button class="btn-icon mt-3"><a href="<?php bp_member_permalink(); ?>"><i class="fas fa-user-friends mr-1"></i><?php esc_html_e( 'Connect with me', 'spaxe-extensions' ); ?></a></button>
						</div>
					</li>
				<?php endwhile; ?>

				</ul>
			<?php endif; ?>
		<?php

		return ob_get_clean();

		}
	}

	function spaxe_members_shortcode( $atts ) {
		/**
		 * Add Members Shortcode.
		 *
		 * Options
		 * Type: Active, Alphabetical, Newest, Online, Popular, Random.
		 * Number: Number of items.
		 * Size: Size of avatar on (px).
		 * Style: rounded, rounded-0, rounded-circle, rounded-bottom, rounded-left, rounded-right, rounded-top.
		 *
		 * @return	spaxe_members
		 */
		extract( shortcode_atts( array(
			'view'			=> 'slider',
			'filter'		=> 'active',
			'number'		=> 10,
			'user_type'		=> null,
			'size'			=> '80',
			'style'			=> ''
		), $atts ) );

		$query = "type=$filter&max=$number";

		return spaxe_members( $query, $style, $size );
	}
}

if ( class_exists( 'WooCommerce' ) ) {
	/**
	 * Products Shortcode.
	 *
	 * @version 1.0.0
	 * @author	OneVoxx
	 */
	if ( ! function_exists( 'spaxe_home_products' ) ) {
		/**
		 * Add Products Shortcode.
		 *
		 * @return	product
		 */
		function spaxe_home_products( $atts ) {

			global $product;

			$atts = shortcode_atts(
				array(
					'type'		=> 'product',
					'order'		=> 'date',
					'orderby'	=> 'title',
					'posts'		=> 2,
					'category'	=> ''
				),

				$atts, 'home_products'
			);

			$loop = new WP_Query( array(
				'post_type'			=> $atts['type'],
				'order'				=> $atts['order'],
				'orderby'			=> $atts['orderby'],
				'posts_per_page'	=> $atts['posts'],
				'tax_query'			=> array( array(
					'taxonomy'		=> 'product_cat',
					'field'			=> 'slug',
					'terms'			=> $atts['category']
				) ),
			) );

			ob_start(); ?>

				<?php if ( $loop->have_posts() ) : ?> 
					<ul class="home-product m-0">
						<?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
							<div class="home-product-content">
								<li class="product">    
									<a href="<?php echo get_permalink( $loop->post->ID ) ?>" class="product-link">
										<?php woocommerce_show_product_sale_flash( $post, $product ); ?>

										<?php if ( has_post_thumbnail( $loop->post->ID ) ) echo get_the_post_thumbnail( $loop->post->ID, 'shop_catalog'); else echo '<img src="' . woocommerce_placeholder_img_src() . '" width="300px" height="300px" />'; ?>
									</a>

									<div class="product-info">
										<h3 class="product_title entry-title"><a href="<?php echo get_permalink( $loop->post->ID ) ?>" class="product-link"><?php the_title(); ?></a></h3>

										<div class="rating">
											<?php add_star_rating(); ?>

											<span class="average-rating"><?php echo $product->get_average_rating(); ?></span>
										</div>

										<div class="product-price">
											<?php echo $product->get_price_html(); ?>
										</div>

										<span class="short-description"><?php echo $product->get_short_description(); ?></span>

										<span class="add-to-cart"><?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?></span>

										<?php spaxe_add_wishlist_button(); ?>
									</div>
								</li>
							</div>
						<?php endwhile; ?>

						<?php wp_reset_postdata(); ?>
					</ul>
				<?php endif; ?>

			<?php
			
			$product = ob_get_clean();

			return $product;
		}
	}
}

/**
 * Add rating to product shortcode.
 */
function add_star_rating() {

	global $woocommerce, $product;

	$average = $product->get_average_rating();

	echo '<div class="star-rating"><span style="width:' . ( ( $average / 5 ) * 100 ) . '%"><strong itemprop="ratingValue" class="rating">' . $average . '</strong> ' . __( 'out of 5', 'spaxe-extensions' ) . '</span></div>';
}

<?php
/**
 * Plugin Name:		Spaxe Extensions
 * Plugin URI:		https://onevoxx.com/spaxe/
 * Author:			OneVoxx
 * Author URL:		https://onevoxx.com/
 * Description:		Spaxe extensions is a plugin for add shortcode to your WordPress pages and anywhere else on your site.
 * Version:			1.0.0
 * Text Domain:		spaxe-extensions
 * Domain Path:		/languages
 * License:			GNU General Public License v3 or later.
 * License URI:		https://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Spaxe_Extensions' ) ) {
	/**
	 * Spaxe_Extensions Class
	 *
	 * @version	1.0.0
	 * @since	1.0.0
	 * @author	OneVoxx
	 */

	final class Spaxe_Extensions {
		/**
		 * Instance
		 *
		 * @var		Spaxe_Extensions The single instance of Spaxe_Extensions.
		 * @access	private
		 * @since	1.0.0
		 */
		private static $_instance = null;

		/**
		 * Spaxe_Extensions Instance
		 *
		 * Ensures only one instance of Spaxe_Extensions is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 *
		 * @access public
		 * @static
		 *
		 * @return Spaxe_Extensions An instance of the class.
		 */
		public static function instance () {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * Constructor function.
		 *
		 * @access	public
		 * @since	1.0.0
		 */
		public function __construct () {
			
			add_action( 'plugins_loaded', array( $this, 'setup_constants' ),			10 );
			add_action( 'plugins_loaded', array( $this, 'includes' ),					20 );
			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ),		30 );
		}

		/**
		 * Setup plugin constants
		 *
		 * @access	public
		 * @since	1.0.0
		 */
		public function setup_constants() {

			// Plugin Folder Path.
			if ( ! defined( 'SPAXE_EXTENSIONS_DIR' ) ) {
				define( 'SPAXE_EXTENSIONS_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL.
			if ( ! defined( 'SPAXE_EXTENSIONS_URL' ) ) {
				define( 'SPAXE_EXTENSIONS_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File.
			if ( ! defined( 'SPAXE_EXTENSIONS_FILE' ) ) {
				define( 'SPAXE_EXTENSIONS_FILE', __FILE__ );
			}

			// Modules File.
			if ( ! defined( 'SPAXE_MODULES_DIR' ) ) {
				define( 'SPAXE_MODULES_DIR', SPAXE_EXTENSIONS_DIR . '/modules' );
			}
		}

		/**
		 * Include required files
		 *
		 * @access	public
		 * @since	1.0.0
		 */
		public function includes() {

			/* Plugin Functions
			-------------------------------------------------------------- */
			require SPAXE_EXTENSIONS_DIR . '/inc/functions.php';

			/* Plugin Shortcodes
			-------------------------------------------------------------- */
			require_once SPAXE_MODULES_DIR . '/shortcodes/shortcodes.php';
		}

		/**
		 * Load the textdomain file.
		 *
		 * @access	public
		 * @since	1.0.0
		 */
		public function load_plugin_textdomain() {

			load_plugin_textdomain( 'spaxe-extensions', false, dirname( plugin_basename( SPAXE_EXTENSIONS_FILE ) ) . '/languages/' );
		}
	}
}

/**
 * Returns the main instance of Spaxe_Extensions to prevent the need to use globals.
 *
 * @since	1.0.0
 * @return	Spaxe_Extensions
 */
function Spaxe_Extensions() {
	return Spaxe_Extensions::instance();
}

/**
 * Initialise the plugin
 */
Spaxe_Extensions();
